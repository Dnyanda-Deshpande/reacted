import React, { Component } from 'react';
import logo from './logo.svg';
import './App.css';



class APP {
  
}

export default APP;