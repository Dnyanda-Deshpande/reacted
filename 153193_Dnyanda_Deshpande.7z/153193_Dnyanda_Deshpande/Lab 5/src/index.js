import React from 'react';
import ReactDOM from 'react-dom';
import './index.css';

import registerServiceWorker from './registerServiceWorker';
import ClockTick from './ClockTick';

ReactDOM.render(<ClockTick />, document.getElementById('root'));
registerServiceWorker();
