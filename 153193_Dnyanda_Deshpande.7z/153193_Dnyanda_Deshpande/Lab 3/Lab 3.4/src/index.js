import React from 'react';
import ReactDOM from 'react-dom';
import './index.css';
import MovieList from './MovieList';
//import {data} from './MovieList';
import registerServiceWorker from './registerServiceWorker';
import HarryPotter from './HarryPotter.jpg';
import Avengers from './Avengers.jpg'

ReactDOM.render(<MovieList pro="Harry Potter" imageUrl={HarryPotter}
                           pro1="Avengers" imageUrl1={Avengers}  />, document.getElementById('root'));
registerServiceWorker();
