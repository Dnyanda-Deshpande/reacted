import React from 'react';

class MovieList extends React.Component{

    render () {
        return (
            <div>
              <h1>
                   {this.props.pro}
                   <img src={this.props.imageUrl}/>
               </h1>  

               <h1>
                   {this.props.pro1}
                   <img src={this.props.imageUrl1}/>
               </h1>   
               
            </div>
        );
    }
};


//export var data={"name":"An ice sculpture"};
export default MovieList;