/*import React, { Component } from 'react';
import {Family} from './mall';
import Person from './mall';
const myContext=React.createContext();

class MyProvider extends Component{
  constructor(props){
    super(props)
    this.state={
    name:'Sayu',
    age:21,
    cool:true
  }
}
  
  render(){
    return(
      <myContext.Provider value={{state:this.state,grow:()=>{
        this.setState({age:this.state.age + 1})}}}>
        {this.props.children}
      </myContext.Provider>
    )
  }
}



class App extends Component {
 
  render() {
    return (
      <MyProvider>
       
       
        <Person/>
      
      </MyProvider>
    
    );
  }
}

export default (App,MyProvider);*/



import React, { Component } from 'react';

import LocaleProvider from './screen';
import Greeting from './theatre';
import ToggleLocale from './mall';

class App extends Component {
  render() {
    return (
      <LocaleProvider>
        <ToggleLocale />
      </LocaleProvider>
    );
  }
}

export default App;
