import React, { Component } from 'react';

var createReactClass = require('create-react-class'); 
var Parent = createReactClass(
{ 
 
	render: function() 
	{
   
		  return <div><p><b>The number of Children In Parent : </b>{React.Children.count(this.props.children)}<br/><br/>
                      <b>The type of Child :</b>{React.Children.map(this.props.children,child=>{
                        return child.type
                      })}<br/><br/>
                      <b>Child Elements Are : </b>{this.props.children}<br/><br/>
                       {React.Children.only(this.props.children)}
                    </p></div>
	}
 }
);

export default Parent;