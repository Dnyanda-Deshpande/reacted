import React from 'react';
import ReactDOM from 'react-dom';
import './index.css';
import registerServiceWorker from './registerServiceWorker';
import MovieList from './movieList';
import HarryPotter from './HarryPotter.jpg';
import Avengers from './Avengers.jpg'


ReactDOM.render(<MovieList price={100} imageUrl={HarryPotter}  price1={200} imageUrl1={Avengers} />, document.getElementById('root'));
registerServiceWorker();
