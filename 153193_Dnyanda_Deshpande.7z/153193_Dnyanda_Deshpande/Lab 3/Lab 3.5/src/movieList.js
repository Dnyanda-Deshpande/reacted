import React from 'react';
import PropTypes from 'prop-types';


class MovieList extends React.Component{
     

    render () {
      
        return (
            <div>
              <h1>
                   {this.props.pro}<br/>
                   Price : {this.props.price} 
               </h1>  
                <img src={this.props.imageUrl} alt=""/>
               <h1>
                   {this.props.pro1}<br/>
                  Price : {this.props.price1}
               </h1>   
               <img src={this.props.imageUrl1} alt=""/>
            </div>
        );
    }
};


MovieList.propTypes = {
    pro:PropTypes.string,
    price:PropTypes.number,
    pro1:PropTypes.string,
    price1:PropTypes.number
}

MovieList.defaultProps = {
    pro:'DEFAULT PRODUCT',
    pro1:'DEFAULT PRODUCT'
}

export default MovieList;
