import React from 'react';

class Task extends React.Component{
    render(){
        return(
            <tr>
                <td>
                    {this.props.task}
                </td>
            </tr>
        )
    }
}



export default Task;