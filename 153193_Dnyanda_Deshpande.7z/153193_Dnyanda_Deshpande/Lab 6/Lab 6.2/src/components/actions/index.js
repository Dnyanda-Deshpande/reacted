export const AddTask=(task)=>{
    return {
        type:'ADD_TASK',
        payload:task
    }
}

